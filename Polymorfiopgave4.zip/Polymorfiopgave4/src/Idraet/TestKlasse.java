package Idraet;

public class TestKlasse {

	public static void main(String[] args) {
		
		Medlem medlem1 = new Senior("Erling", 75);
			System.out.println(medlem1 + ", kontingent: " + medlem1.kontingent());
			
		Medlem medlem2 = new Junior("Hans", 9, "Valdemar");
			System.out.println(medlem2 + ", kontingent: " + medlem2.kontingent());
		
		Medlem medlem3 = new Junior("Peter", 16, "Vera");
			System.out.println(medlem3 + ", kontingent: " + medlem3.kontingent());
	}

}
