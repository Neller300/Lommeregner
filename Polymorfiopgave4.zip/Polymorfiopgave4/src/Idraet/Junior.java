package Idraet;

public class Junior extends Medlem {
	
	private String parent;
	
	public Junior(String navn, int alder, String parent) {
		super(navn, alder);
		this.parent = parent;
	}
	
	public int kontingent() {
		if(alder < 15) 
			return 150;
		else
			return 250;
	}
	
	public String toString() {
		return "Junior: " + super.toString() + ", for�ldre: " + parent + "";
	}
	}
	


