package application;
	
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;


public class Main extends Application {
	
	
	@Override
	public void start (Stage Stage) {
		GridPane grid = new GridPane();
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(15,15,15,15));
		
	    StackPane stack = new StackPane();
	    stack.getChildren().addAll(new Rectangle(430,165,Color.BLACK));
	    grid.add(stack, 0, 0, 4, 1);
	    
	    
	
	Extbutton nul = new Extbutton("0", "0", InputType.NUMBER);
	grid.add(nul, 1, 6);
	
	Extbutton et = new Extbutton("1", "1", InputType.NUMBER);
	grid.add(et, 0, 5);
	
	Extbutton to = new Extbutton("2", "2", InputType.NUMBER);
	grid.add(to, 1, 5);
	
	Extbutton tre = new Extbutton("3", "3", InputType.NUMBER);
	grid.add(tre, 2, 5);
	
	Extbutton fire = new Extbutton("4", "4", InputType.NUMBER);
	grid.add(fire, 0, 4);
	
	Extbutton fem = new Extbutton("5", "5", InputType.NUMBER);
	grid.add(fem, 1, 4);
	
	Extbutton seks = new Extbutton("6", "6", InputType.NUMBER);
	grid.add(seks, 2, 4);
	
	Extbutton syv = new Extbutton("7", "7", InputType.NUMBER);
	grid.add(syv, 0, 3);
	
	Extbutton otte = new Extbutton("8", "8", InputType.NUMBER);
	grid.add(otte, 1, 3);
	
	Extbutton ni = new Extbutton("9", "9", InputType.NUMBER);
	grid.add(ni, 2, 3);
	
	Extbutton punktum = new Extbutton(".", ".", InputType.NUMBER);
	grid.add(punktum, 2, 6);
	
	Extbutton ligmed = new Extbutton("=", "=", InputType.UTILITY);
	grid.add(ligmed, 3, 6);
	
	Extbutton plus = new Extbutton("+", "+", InputType.OPERATOR);
	grid.add(plus, 3, 5);
	
	Extbutton minus = new Extbutton("-", "-", InputType.OPERATOR);
	grid.add(minus, 3, 4);
	
	Extbutton gange = new Extbutton("*", "*", InputType.OPERATOR);
	grid.add(gange, 3, 3);
	
	Extbutton divider = new Extbutton("/", "/", InputType.OPERATOR);
	grid.add(divider, 3, 2);
	
	Extbutton parentesStart = new Extbutton("(", "(", InputType.UTILITY);
	grid.add(parentesStart, 2, 1);
	
	Extbutton parentesSlut = new Extbutton(")", ")", InputType.UTILITY);
	grid.add(parentesSlut, 3, 1);
	
	Extbutton kvadratrod = new Extbutton("\u221A" , "\u221A", InputType.OPERATOR);
	grid.add(kvadratrod, 2, 2);
	
	Extbutton IAnden = new Extbutton("\u00B2", "x\u00B2", InputType.OPERATOR);
	grid.add(IAnden, 1, 1);
	
	Extbutton Clear = new Extbutton("CE", "CE", InputType.UTILITY);
	grid.add(Clear, 0, 2);
	
	Extbutton delete = new Extbutton("\u232B", "\u232B", InputType.UTILITY);
	grid.add(delete, 1, 2);
	
	Extbutton ChangeSign = new Extbutton("(-) +-", "(-) +-", InputType.NUMBER);
	grid.add(ChangeSign, 0, 6);
	
	Extbutton Percent = new Extbutton("%", "%", InputType.UTILITY);
	grid.add(Percent, 0, 1);
	
	
	
	Scene scene = new Scene(grid,460, 795);
	Stage.setScene(scene);
	Stage.setTitle("Calculator 3000");
	Stage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
