package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class Extbutton extends Button{

	public String input;
	public String ShowButtonText;
	
	
	public Extbutton(String input, String showbuttext, InputType type) {
	
	super(showbuttext);
	this.input = input;
	ShowButtonText = showbuttext;
	
	
	
		super.setPrefSize(100,90);
		//super.setStyle("-fx-background-color: ; ");
		//super.setFont(helvitica);
		super.setStyle("-fx-font: 25 Helvitica; -fx-font-weight: bold;");
		super.setHover(isScaleShape());
		super.setDefaultButton(isPressed());
		//super.setTextFill(value);
		//super
		
		
		
		
		//buttOnclicked.setOnAction(new EventHandler<ActionEvent>() {
			//@Override
			//public void handle(ActionEvent e) {
				
			}
		
	
}

