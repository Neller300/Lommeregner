package application;

	public enum InputType {NUMBER, OPERATOR, UTILITY}

