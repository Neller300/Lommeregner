package calculatorPackage;

import java.util.HashMap;

import calculatorPackage.calculatorTools.nodeType;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class GUICreator
{
	public Text text;

	public Scene theScene;
	
	public DisplayHandler theDisplay;

	public GUICreator(InputHandler tHandler)
	{

		GridPane grid = new GridPane();
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(15, 15, 15, 15));

		StackPane stack = new StackPane();
		stack.getChildren().addAll(new Rectangle(430, 165, Color.BLACK));
		text = new Text();
		text.setFill(Color.WHITE);
		text.setStyle("-fx-font: 25 Consolas; -fx-font-weight: bold;");
		HBox textHolder = new HBox();
		textHolder.setAlignment(Pos.TOP_LEFT);
		textHolder.getChildren().add(text);
		stack.getChildren().add(textHolder);
		grid.add(stack, 0, 0, 4, 1);
		text.setWrappingWidth(430);

		DisplayHandler.theGUICreator=this;
		
		theScene = new Scene(grid, 460, 840);

		ExtButton nul = new ExtButton("0", "0", nodeType.NUMBER, 0, tHandler);
		grid.add(nul, 1, 6);

		ExtButton et = new ExtButton("1", "1", nodeType.NUMBER, 0, tHandler);
		grid.add(et, 0, 5);

		ExtButton to = new ExtButton("2", "2", nodeType.NUMBER, 0, tHandler);
		grid.add(to, 1, 5);

		ExtButton tre = new ExtButton("3", "3", nodeType.NUMBER, 0, tHandler);
		grid.add(tre, 2, 5);

		ExtButton fire = new ExtButton("4", "4", nodeType.NUMBER, 0, tHandler);
		grid.add(fire, 0, 4);

		ExtButton fem = new ExtButton("5", "5", nodeType.NUMBER, 0, tHandler);
		grid.add(fem, 1, 4);

		ExtButton seks = new ExtButton("6", "6", nodeType.NUMBER, 0, tHandler);
		grid.add(seks, 2, 4);

		ExtButton syv = new ExtButton("7", "7", nodeType.NUMBER, 0, tHandler);
		grid.add(syv, 0, 3);

		ExtButton otte = new ExtButton("8", "8", nodeType.NUMBER, 0, tHandler);
		grid.add(otte, 1, 3);

		ExtButton ni = new ExtButton("9", "9", nodeType.NUMBER, 0, tHandler);
		grid.add(ni, 2, 3);

		ExtButton punktum = new ExtButton(".", ".", nodeType.NUMBER, 0, tHandler);
		grid.add(punktum, 2, 6);

		ExtButton ligmed = new ExtButton("=", "=", nodeType.UTILITY, 0, tHandler);
		grid.add(ligmed, 3, 6);

		ExtButton plus = new ExtButton("+", "+", nodeType.OPERATOR, 0, tHandler);
		grid.add(plus, 3, 5);

		ExtButton minus = new ExtButton("-", "-", nodeType.OPERATOR, 0, tHandler);
		grid.add(minus, 3, 4);

		ExtButton gange = new ExtButton("*", "*", nodeType.OPERATOR, 0, tHandler);
		grid.add(gange, 3, 3);

		ExtButton divider = new ExtButton("/", "/", nodeType.OPERATOR, 0, tHandler);
		grid.add(divider, 3, 2);

		ExtButton parentesStart = new ExtButton("(", "(", nodeType.UTILITY, 0, tHandler);
		grid.add(parentesStart, 2, 1);

		ExtButton parentesSlut = new ExtButton(")", ")", nodeType.UTILITY, 0, tHandler);
		grid.add(parentesSlut, 3, 1);

		ExtButton kvadratrod = new ExtButton("\u221A", "\u221A", nodeType.OPERATOR, 1, tHandler);
		grid.add(kvadratrod, 2, 2);

		ExtButton IAnden = new ExtButton("\u00B2", "x\u00B2", nodeType.OPERATOR, -1, tHandler);
		grid.add(IAnden, 1, 1);

		ExtButton Clear = new ExtButton("CE", "CE", nodeType.UTILITY, 0, tHandler);
		grid.add(Clear, 0, 2);

		ExtButton delete = new ExtButton("\u232B", "\u232B", nodeType.UTILITY, 0, tHandler);
		grid.add(delete, 1, 2);

		ExtButton ChangeSign = new ExtButton("(-) +-", "(-) +-", nodeType.NUMBER, 0, tHandler);
		grid.add(ChangeSign, 0, 6);

		ExtButton Percent = new ExtButton("%", "%", nodeType.UTILITY, 0, tHandler);
		grid.add(Percent, 0, 1);
		
		ExtButton xButton = new ExtButton("X", "X", nodeType.NUMBER, 0, tHandler);
		grid.add(xButton, 0, 7);

		ExtButton openGraph = new ExtButton("GRAPH", "GRAPH", nodeType.UTILITY, 0, tHandler);
		grid.add(openGraph, 1, 7);

		theScene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				
				HashMap<KeyCode, ExtButton> map = new HashMap<KeyCode, ExtButton>();
				map.put(KeyCode.DIGIT0, nul);
				map.put(KeyCode.NUMPAD0, nul);
				map.put(KeyCode.DIGIT1, et);
				map.put(KeyCode.NUMPAD1, et);
				map.put(KeyCode.DIGIT2, to);
				map.put(KeyCode.NUMPAD2, to);
				map.put(KeyCode.DIGIT3, tre);
				map.put(KeyCode.NUMPAD3, tre);
				map.put(KeyCode.DIGIT4, fire);
				map.put(KeyCode.NUMPAD4, fire);
				map.put(KeyCode.DIGIT5, fem);
				map.put(KeyCode.NUMPAD5, fem);
				map.put(KeyCode.DIGIT6, seks);
				map.put(KeyCode.NUMPAD6, seks);
				map.put(KeyCode.DIGIT7, syv);
				map.put(KeyCode.NUMPAD7, syv);
				map.put(KeyCode.DIGIT8, otte);
				map.put(KeyCode.NUMPAD8, otte);
				map.put(KeyCode.DIGIT9, ni);
				map.put(KeyCode.NUMPAD9, ni);
				map.put(KeyCode.PLUS, plus);
				map.put(KeyCode.ADD, plus);
				map.put(KeyCode.MINUS, minus);
				map.put(KeyCode.SUBTRACT, minus);
				map.put(KeyCode.MULTIPLY, gange);
				map.put(KeyCode.QUOTE, gange);
				map.put(KeyCode.DIVIDE, divider);
				map.put(KeyCode.LEFT_PARENTHESIS, parentesStart);
				map.put(KeyCode.RIGHT_PARENTHESIS, parentesSlut);
				map.put(KeyCode.ENTER, ligmed);
				map.put(KeyCode.BACK_SPACE, delete);
				map.put(KeyCode.ESCAPE, Clear);
				
				KeyCode keyCode = event.getCode();
				
				System.out.println("key pressed: " + keyCode);
				
				if (map.containsKey(keyCode)) {
					System.out.println("pressed numeric key");
					ExtButton button = map.get(keyCode);
					
					button.activate();
					button.requestFocus();
				}
			}});
	}

	public Scene getScene()
	{
		return theScene;
	}
}
