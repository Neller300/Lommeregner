package calculatorPackage;

public class calculatorTools
{
	public static enum nodeType {OPERATOR, NUMBER, PARENTHESIS, UTILITY};
	
	public static enum displayType {CALCULATOR, Y1, Y2, Y3};
}
